OctSymPy for Matlab
===================

README.md is the main document.  Here we list any Matlab-specific notes.

Formatting: Matlab uses a different formatting for comment headers.
Most of the .m files have been autoconverted from the GNU Octave
versions.

Tests: Many .m files have tests built-in using using Octave's test framework.
These have been autoextracted for Matlab (which unfortunately doesn't use the
same test framework).


